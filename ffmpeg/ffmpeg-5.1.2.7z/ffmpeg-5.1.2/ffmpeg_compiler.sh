#!/bin/bash

# Script is to be run from ffmpeg base directory.
# This script compiles and creates a package for the FFmpeg version specified in VERSION.
# Compilation target is x86_64 mingw32

set -e

THIS=$(readlink -e $0)
VERSION=5.1.2
INSTALL_DIR=ffmpeg-${VERSION}

REQUIRED_DLLS_NAME=requirements.txt
REQUIRED_DLLS="avcodec-58.dll;avutil-56.dll;libwinpthread-1.dll;swscale-5.dll"

git checkout n${VERSION}
mkdir build || true
cd build
../configure --enable-cross-compile --arch=x86_64 --target-os=mingw32 --cross-prefix=x86_64-w64-mingw32- --disable-avdevice --disable-avfilter --disable-avformat --disable-doc --disable-everything --disable-ffmpeg --disable-ffprobe --disable-network --disable-postproc --disable-swresample --disable-vaapi --disable-vdpau --enable-decoder=h264 --enable-decoder=vp9 --enable-shared --prefix=/
make -j$(nproc)

mkdir ${INSTALL_DIR}
make install DESTDIR=${INSTALL_DIR}
cp ${THIS} ${INSTALL_DIR}
echo -n ${REQUIRED_DLLS} > ${INSTALL_DIR}/${REQUIRED_DLLS_NAME}
cp $(find /usr/x86_64-w64-mingw32/ | grep libwinpthread-1.dll | head -n 1) ${INSTALL_DIR}/bin
7z a ${INSTALL_DIR}.7z ${INSTALL_DIR}
